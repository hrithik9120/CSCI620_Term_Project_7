# Reddit Comments May 2015 Dataset Loader

Automated Python script to download the Kaggle dataset "Reddit Comments May 2015", then parse it from its original SQLite format and load data into PostgreSQL. The programs handle all setup steps automatically without manual intervention.

**Dataset**: https://www.kaggle.com/datasets/kaggle/reddit-comments-may-2015

### Script name - `load_data.py` - Multi-Table Normalized Loader
- Loads data into normalized tables (User, Subreddit, Post, Post_Link, Comment, Moderation)
- Uses pandas for efficient data processing
- Schema-aligned with proper foreign key relationships
- Optimized batch processing

### Project Directory Structure
```bash
CSCI620_TERM_PROJECT_GROUP_7/
│
├── relational_schema/
│   ├── create_ddl_queries.sql        # PostgreSQL DDL (table creation)
│   ├── relational_schema.jpg         # Relational Model diagram representation
│   └── test_queries.sql              # Validation and integrity test queries
│
├── load_data.py                      # Main data loading script
├── requirements.txt                  # Python dependencies
├── README.md                         # Project documentation
├── Data Description.docx             # Detailed description of reddit2015 dataset
│
└── kaggle.json                       # Kaggle API credentials (excluded in submission)
```

## Requirements

- Python 3.6+
- PostgreSQL server running and accessible
- SQLite database file containing Reddit comments data

## Installation

```bash
pip install -r requirements.txt
```

### Dependencies
- `psycopg2-binary`: PostgreSQL database adapter
- `pandas`: Data manipulation and analysis
- `requests`: HTTP library for Kaggle API
- `tqdm`: Progress bars for downloads
- `zipfile` – Extracts the Kaggle dataset.
- `json` – Loads Kaggle API credentials (kaggle.json) securely for authenticated downloads.
- `sqlite3` – Reads the original Reddit dataset stored in SQLite format.

## Configuration

1. Ensure PostgreSQL server is running on your system
2. Note your PostgreSQL connection details (host, username, password)
3. The programs will automatically create the database if it doesn't exist
4. For multi-table loader: Ensure PostgreSQL schema is created (run `create_ddl_queries.sql` first)

## Usage

### Multi-Table Normalized Loader Data Loader (`load_data.py`)

```bash
# Load full dataset into normalized tables
python load_data.py --input database.sqlite --host localhost --port 5432 --user postgres --password yourpass --dbname redditdb

# Load sample for testing
python load_data.py --input database.sqlite --host localhost --port 5432 --user postgres --password yourpass --dbname redditdb --sample 1000

# Use existing SQLite file
python load_data.py --input database.sqlite --password yourpass --dbname redditdb

# Custom PostgreSQL configuration
python load_data.py --host 192.168.1.100 --port 5433 --user myuser --password yourpass --dbname redditdb
```

### TROUBLESHOOTING

• "Connection refused" error: Ensure PostgreSQL is running
• "Missing kaggle.json": Download API token from Kaggle account
• "Permission denied": Check PostgreSQL user privileges
• "Disk space full": Dataset requires ~50GB during processing
• "Memory error": Use --sample parameter for testing
• Download timeout: Ensure stable internet for compressed 20GB download

### AUTOMATIC STEPS:

1. Connects to Kaggle and downloads the dataset
2. Extracts the Dataset and Read data from it sqlite, parse it pandas for efficient processing
3. Connects to PostgreSQL database using provided credentials
4. Separates data into normalized tables (User, Subreddit, Post, Post_Link, Comment, Moderation)
5. Applies table-specific preprocessing and data cleaning
6. Loads data in batches of 10,000 records for optimal performance
7. Provides progress updates every 100,000 records
8. Handles errors gracefully and continues processing
9. Reports final statistics for each table

## Command Line Options

Both scripts support the same command line options:

- `--input`: Path to SQLite database file (required)
- `--host`: PostgreSQL server host (default: localhost)
- `--port`: PostgreSQL server port (default: 5432)
- `--user`: PostgreSQL username (default: postgres)
- `--password`: PostgreSQL password (required)
- `--dbname`: PostgreSQL database name (required)
- `--sample`: Load only first N rows for testing (optional)

## Automatic Steps

Both programs handle all steps automatically without manual intervention:

### Multi-Table Loader (`load_data.py`)
1. **Connection**: Connects to PostgreSQL database
2. **Data Reading**: Reads data from SQLite using pandas
3. **Table Processing**: Loads data into normalized tables in dependency order
4. **Data Cleaning**: Applies table-specific preprocessing
5. **Batch Loading**: Loads data in batches of 10,000 records
6. **Progress Reporting**: Provides real-time progress updates
7. **Error Handling**: Gracefully handles errors and continues processing
8. **Statistics**: Reports final statistics for each table

## Features

### Common Features
- **Automatic Database Creation**: Creates PostgreSQL database if it doesn't exist
- **SQLite to PostgreSQL Conversion**: Automatically converts SQLite data to PostgreSQL format
- **Port Configuration**: Supports custom PostgreSQL ports
- **Error Handling**: Graceful error handling for data conversion issues
- **Sample Mode**: Test with limited data using --sample parameter
- **Memory Efficient**: Processes data in batches without loading entire dataset into memory
- **Progress Tracking**: Real-time progress updates and final statistics
- **No Manual Intervention**: Complete automation from start to finish

### Multi-Table Loader
- **Normalized Schema**: Loads into 6 normalized tables (User, Subreddit, Post, Post_Link, Comment, Moderation)
- **Pandas Integration**: Uses pandas for efficient data manipulation
- **Foreign Key Management**: Maintains proper relationships between tables
- **Data Cleaning**: Table-specific preprocessing and validation
- **Schema Alignment**: Compatible with PostgreSQL schema requirements
